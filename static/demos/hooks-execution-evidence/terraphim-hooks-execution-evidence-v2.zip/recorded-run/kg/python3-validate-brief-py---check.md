---
type::: kg_entry
correction_type: tool_preference
captured_at: 2026-10-13T15:45:41.727046+00:00
source: learned
synonyms:: python3 validate-brief.py --chek
priority:: 70
pinned:: false
---

# python3 validate-brief.py --check

## Original

Multiple alternatives resolved to this correction:
- `python3 validate-brief.py --chek`

## Corrected

`python3 validate-brief.py --check`

## Context

- Manually reviewed correction from actual captured learning ee1b353f8869495494567b7d21b2ec9e-1791906336536

