---
id: ee1b353f8869495494567b7d21b2ec9e-1791906336536
command: python3 validate-brief.py --chek
exit_code: 2
source: Global
captured_at: 2026-10-13T15:45:36.536384+00:00
working_dir: /private/tmp/terraphim-hooks-trace-20261013-run2
correction: python3 validate-brief.py --check
tags:
  - learning
  - exit-2
importance_total: 0.3200
importance_severity: 0.4000
importance_repetition: 0
importance_recency: 1.0000
importance_has_correction: false
---

## Command

`python3 validate-brief.py --chek`

## Error Output

```
usage: validate-brief.py [-h] --check
validate-brief.py: error: the following arguments are required: --check

```

## Suggested Correction

`python3 validate-brief.py --check`

