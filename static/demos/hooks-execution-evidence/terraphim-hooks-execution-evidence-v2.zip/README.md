# Hooks execution evidence

See reproduction/README.md for setup. Run commands from reproduction/, or from this directory:

```sh
python3 reproduction/reproduce.py --agent /absolute/path/to/terraphim-agent --model kimi-code-plan-global/k3 --output /absolute/path/to/a-new-run
node reproduction/verify.mjs /absolute/path/to/a-new-run
node --test tests/*.test.mjs
node reproduction/verify.mjs recorded-run
```

recorded-run/ contains the actual recorded demonstration outputs. Their absolute working-directory references identify the original run; each fresh reproduction writes new paths and execution IDs.
