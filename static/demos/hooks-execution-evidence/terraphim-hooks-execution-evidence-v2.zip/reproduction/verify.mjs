import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { verifyReceipt } from './fixture/.opencode/plugins/terraphim-demo/execution-trace.mjs';
const root=path.resolve(process.argv[2]);
const events=fs.readFileSync(path.join(root,'evidence/host-events.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
const executionRoot=path.join(root,'evidence/executions');
const receipts=fs.readdirSync(executionRoot).map(id=>JSON.parse(fs.readFileSync(path.join(executionRoot,id,'receipt.json'))));
assert.equal(receipts.length,2,'Exactly one baseline and one corrected execution required');
const executionIds=new Set(receipts.map(r=>r.execution_id));
assert.equal(executionIds.size,receipts.length,'Unique receipt execution IDs required');
const nativeEvents=events.filter(e=>e.type==='native-before'||e.type==='native-after');
for(const e of nativeEvents) {
  assert.ok(executionIds.has(e.data?.execution_id),'Unmatched native event has no receipt');
}
for(const type of ['native-before','native-after']) {
  assert.equal(nativeEvents.filter(e=>e.type===type).length,receipts.length,`${type} count must match receipts`);
}
for(const r of receipts) {
  verifyReceipt(root,r);
  const before=events.filter(e=>e.type==='native-before'&&e.data.execution_id===r.execution_id);
  const after=events.filter(e=>e.type==='native-after'&&e.data.execution_id===r.execution_id);
  assert.equal(before.length,1);assert.equal(after.length,1);
  for(const e of [before[0],after[0]]) {
    assert.equal(e.data.id,r.host.tool_call_id);assert.equal(e.data.sessionID,r.host.session_id);
  }
  assert.deepEqual(before[0].data.input,r.original_input);
  assert.deepEqual(after[0].data.input,r.executed_input);
  assert.equal(after[0].data.result.metadata.exit,r.tool_result.exit_code);
  assert.equal(after[0].data.result.output.output,r.tool_result.combined_output);
}
assert.deepEqual(receipts.map(r=>r.tool_result.exit_code).sort(),[0,2]);
assert.equal(fs.existsSync(path.join(root,'evidence/active-execution.json')),false);
console.log(JSON.stringify({pass:true,executions:receipts.map(r=>({execution_id:r.execution_id,rule:r.matched_rule,exit:r.tool_result.exit_code,artifact:r.artifact}))},null,2));
