#!/usr/bin/env python3
"""Reproduce the public Harbour fixture with actual released binary and coding host.

Requires Python 3, the checksum-verified terraphim-agent binary, OpenCode 2.0.20,
and an already authenticated subscription model. No global hooks/config are changed.
"""
import argparse, hashlib, json, os, re, shutil, subprocess, time
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--agent',required=True,type=Path,help='Checksum-verified terraphim-agent executable')
parser.add_argument('--model',required=True,help='An already-authenticated subscription model; no automatic fallback')
parser.add_argument('--host',default='opencode')
parser.add_argument('--output',type=Path,default=Path('reproduction-run'))
a=parser.parse_args()
binary=a.agent.resolve(); root=a.output.resolve()
if root.exists():raise SystemExit('Output directory already exists; choose a fresh path')
root.mkdir(parents=True)
shutil.copytree(Path(__file__).resolve().parent/'fixture',root,dirs_exist_ok=True)
for d in ['evidence','.qualification/data','.qualification/settings','.qualification/sqlite','.qualification/dashmap','.qualification/opencode-config','empty-kg','kg']:(root/d).mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
# OpenCode reads PWD; do not inherit the launcher directory when cwd changes.
env.pop("PWD",None)
env.update(TERRAPHIM_DEFAULT_DATA_PATH=str(root/'.qualification/data'),TERRAPHIM_SETTINGS_PATH=str(root/'.qualification/settings'),OPENCODE_CONFIG_DIR=str(root/'.qualification/opencode-config'),TERRAPHIM_HOOK_DEMO_AGENT=str(binary))
(root/'.qualification/settings/settings.toml').write_text(f'''server_hostname="127.0.0.1:8000"
api_endpoint="http://127.0.0.1:8000/api"
initialized="false"
default_data_path="{root}/.qualification/data"
[profiles.dashmap]
type="dashmap"
root="{root}/.qualification/dashmap"
[profiles.sqlite]
type="sqlite"
datadir="{root}/.qualification/sqlite"
connection_string="{root}/.qualification/sqlite/terraphim.db"
table="terraphim_kv"
''')
config=json.loads((root/'opencode.json').read_text());config['model']=a.model;(root/'opencode.json').write_text(json.dumps(config,indent=2))

def save(name,obj):
 (root/'evidence'/name).write_text(json.dumps(obj,indent=2)+'\n')

def run(name,argv,stdin=None,limit=120):
 started=time.time();result=subprocess.run(argv,input=stdin,text=True,capture_output=True,env=env,cwd=root,timeout=limit)
 save(name+'.json',{'argv':argv,'cwd':str(root),'stdin':stdin,'stdout':result.stdout,'stderr':result.stderr,'exit_code':result.returncode,'elapsed_seconds':round(time.time()-started,3)})
 if result.returncode:raise RuntimeError(f'{name}: exit {result.returncode}; inspect evidence')
 return result.stdout

def cli(name,*args,stdin=None):return run(name,[str(binary),*args],stdin)

def role_config(compiled):
 roles={}
 for role in ['Harbour Validator','Unrelated Project']:
  kg={'automata_path':{'Local':str(root/'compiled-corrections.json')},'knowledge_graph_local':None,'public':False,'publish':False} if compiled and role=='Harbour Validator' else {'automata_path':None,'knowledge_graph_local':{'input_type':'markdown','path':str(root/'empty-kg')},'public':False,'publish':False}
  roles[role]={'name':role,'shortname':'harbour','relevance_function':'terraphim-graph','terraphim_it':True,'theme':'lumen','kg':kg,'haystacks':[],'extra':{}}
 return {'id':'Server','global_shortcut':'Ctrl+Shift+T','roles':roles,'default_role':'Harbour Validator','selected_role':'Harbour Validator'}
(root/'empty-config.json').write_text(json.dumps(role_config(False),indent=2))
version=cli('binary-version','--version').strip()
host_version=run('host-version',[a.host,'--version']).strip()
save('identities.json',{'terraphim_agent':version,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'host':host_version,'model':a.model,'note':'Only public fixture sent to the coding model. Hook processing is local; no blanket no-network claim.'})
cli('empty-store','learn','list')
(root/'demo-mode.json').write_text(json.dumps({'rewrite':False,'config':'empty-config.json'}))
prompt='Use the shell tool exactly once. Set its command field to this exact JSON string: "python3 validate-brief.py --chek"\nDo not append anything. This is a harmless public validator fixture; do not repair the command, read files or use other tools. Report the actual output and exit status then stop.' 

def host(name):
 out=run(name,[a.host,'run','--standalone','--format','json','--model',a.model,prompt],limit=180)
 (root/'evidence'/(name+'.jsonl')).write_text(out)
 if any(json.loads(x).get('type')=='error' for x in out.splitlines() if x.startswith('{')):raise RuntimeError('Host reported an error; inspect evidence')

host('baseline-host')
assert not list((root/'evidence/executions').glob('*/validation.json')),'Baseline unexpectedly generated a result'
events=[json.loads(x) for x in (root/'evidence/host-events.jsonl').read_text().splitlines()]
after=[x['data'] for x in events if x['type']=='native-after']
assert len(after)==1 and after[0]['status']=='completed', 'Baseline did not execute; inspect retained host events'
assert after[0]['result']['metadata']['exit']==2
learning_files=list((root/'.qualification/data/terraphim/learnings').glob('learning-*.md'))
assert len(learning_files)==1,'Host event did not create exactly one learning'
learning=learning_files[0];learning_id=re.search(r'^id: (.+)$',learning.read_text(),re.M).group(1)
(root/'evidence/learning-before-correction.md').write_text(learning.read_text())
cli('save-correction','learn','correct',learning_id,'--correction','python3 validate-brief.py --check')
(root/'evidence/learning-after-correction.md').write_text(learning.read_text())
cli('learning-only-compile','learn','compile','--output',str(root/'learning-only.json'))
assert not json.loads((root/'learning-only.json').read_text())['data'],'Unexpected automatic promotion; re-review the release'
cli('manual-promotion','learn','correction','add','--correction-type','tool-preference','--original','python3 validate-brief.py --chek','--corrected','python3 validate-brief.py --check','--context','Manually reviewed correction from actual captured learning '+learning_id)
cli('compile-corrections','learn','compile','--output',str(root/'compiled-corrections.json'))
cli('export-kg','learn','export-kg','--output',str(root/'kg'))
(root/'config.json').write_text(json.dumps(role_config(True),indent=2))
input_json=json.dumps({'tool_name':'Bash','tool_input':{'command':'python3 validate-brief.py --chek'}})
base=['--config',str(root/'config.json'),'hook','--hook-type','pre-tool-use','--role','Harbour Validator','--json']
off=json.loads(cli('rewrite-disabled',*base,stdin=input_json));assert off['tool_input']['command'].endswith('--chek')
on=json.loads(cli('rewrite-enabled',*base,'--rewrite',stdin=input_json));assert on['tool_input']['command'].endswith('--check')
negative=json.dumps({'tool_name':'Bash','tool_input':{'command':'printf harmless'}})
assert json.loads(cli('unrelated-command',*base,'--rewrite',stdin=negative))==json.loads(negative)
scope=json.loads(cli('unrelated-role','--config',str(root/'config.json'),'hook','--hook-type','pre-tool-use','--role','Unrelated Project','--json','--rewrite',stdin=input_json));assert scope['tool_input']['command'].endswith('--chek')
(root/'demo-mode.json').write_text(json.dumps({'rewrite':True,'config':'config.json'}))
host('corrected-host')
events=[json.loads(x) for x in (root/'evidence/host-events.jsonl').read_text().splitlines()]
before=[x['data'] for x in events if x['type']=='native-before'];after=[x['data'] for x in events if x['type']=='native-after']
assert len(before)==2 and len(after)==2
assert before[-1]['input']['command']=='python3 validate-brief.py --chek'
assert after[-1]['input']['command']=='python3 validate-brief.py --check'
assert after[-1]['result']['metadata']['exit']==0
execution_id=after[-1]['execution_id']
result_path=root/'evidence/executions'/execution_id/'validation.json'
assert json.loads(result_path.read_text())=={'execution_id':execution_id,'project':'Harbour','status':'valid','fields':['Decision','Risk','Owner']}
run('trace-verification',['node',str(Path(__file__).resolve().parent/'verify.mjs'),str(root)])
trace=json.loads((root/'evidence/executions'/execution_id/'receipt.json').read_text())
cli('new-process-readback','learn','list')
save('verification.json',{'pass':True,'execution_id':execution_id,'matched_rule':trace['matched_rule'],'artifact':trace['artifact'],'baseline_exit':2,'corrected_exit':0,'host_attempted':'python3 validate-brief.py --chek','host_executed':'python3 validate-brief.py --check','manual_promotion':True,'native_adapter_required':True,'rewrite_off_preserves_input':True,'unrelated_command_preserved':True,'unrelated_role_preserved':True,'privacy_claim':'Public fixture only; known v1.21.19 redaction limitations are documented separately.'})
print(json.dumps({'pass':True,'output':str(root),'result':json.loads(result_path.read_text())},indent=2))
