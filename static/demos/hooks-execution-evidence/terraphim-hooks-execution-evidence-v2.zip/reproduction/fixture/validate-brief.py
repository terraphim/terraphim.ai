from pathlib import Path
import argparse, json, re
parser=argparse.ArgumentParser(description="Validate the fictional Harbour project brief")
parser.add_argument("--check",action="store_true",required=True)
args=parser.parse_args()
text=Path("brief.md").read_text()
assert all(x in text for x in ("Decision:","Risk:","Owner:")), "Brief is missing a required field"
marker=json.loads(Path("evidence/active-execution.json").read_text())
execution_id=marker["execution_id"]
assert re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",execution_id)
output=Path("evidence/executions")/execution_id/"validation.json"
assert marker["artifact_path"]==str(output)
assert not output.exists(), "Output already exists; refusing stale artifact"
result={"execution_id":execution_id,"project":"Harbour", "status":"valid", "fields":["Decision","Risk","Owner"]}
with output.open("x") as f:
 f.write(json.dumps(result,indent=2)+"\n")
print(json.dumps(result))
