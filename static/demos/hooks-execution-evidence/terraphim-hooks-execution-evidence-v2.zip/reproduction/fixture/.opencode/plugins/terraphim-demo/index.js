// Tested with OpenCode 2.0.20. Explicit adapter, not native Terraphim event support.
import fs from 'node:fs';
import { spawnSync } from 'node:child_process';
import { ExecutionTrace } from './execution-trace.mjs';
export default {
  id: 'terraphim-public-demo',
  async setup(ctx) {
    const root=ctx.location.directory;
    const binary=process.env.TERRAPHIM_HOOK_DEMO_AGENT;
    const trace=new ExecutionTrace(root);
    if(!binary)throw new Error('Set TERRAPHIM_HOOK_DEMO_AGENT to the verified released binary');
    const write=(type,data)=>fs.appendFileSync(root+'/evidence/host-events.jsonl',JSON.stringify({type,time:new Date().toISOString(),data})+'\n');
    write('plugin-loaded',{version:ctx.app.version,directory:root});
    const run=(args,event)=>{
      const result=spawnSync(binary,args,{cwd:root,input:JSON.stringify(event),encoding:'utf8',timeout:10000,env:{...process.env,TERRAPHIM_SETTINGS_PATH:root+'/.qualification/settings',TERRAPHIM_DEFAULT_DATA_PATH:root+'/.qualification/data'}});
      write('released-cli',{args,input:event,exit:result.status,stdout:result.stdout,stderr:result.stderr});
      if(result.error||result.status!==0)throw new Error('Terraphim fixture hook failed; inspect the retained receipt');
      return {value:JSON.parse(result.stdout),receipt:{exit:result.status,stdout:result.stdout,stderr:result.stderr}};
    };
    await ctx.tool.hook('execute.before',async event=>{
      if(event.tool!=='shell')return;
      const mode=JSON.parse(fs.readFileSync(root+'/demo-mode.json','utf8'));
      const record=trace.prepare(event,mode);
      write('native-before',{...event,execution_id:record.execution_id});
      try {
      const args=['--config',root+'/'+record.config_path,'hook','--hook-type','pre-tool-use','--role','Harbour Validator','--json'];
      if(mode.rewrite)args.push('--rewrite');
      const {value:result,receipt}=run(args,{tool_name:'Bash',tool_input:{command:event.input.command}});
      if(result.hookSpecificOutput?.permissionDecision==='deny')throw new Error(result.hookSpecificOutput.permissionDecisionReason);
      const command=result.tool_input?.command;
      if(typeof command!=='string')throw new Error('Unexpected Terraphim rewrite output');
      // Apply the returned command through the actual OpenCode V2 hook contract.
      trace.apply(event,command,receipt);
      write('applied-input',{...event.input,execution_id:record.execution_id});
      } catch(error) {trace.fail(event,error);throw error;}
    });
    await ctx.tool.hook('execute.after',async event=>{
      if(event.tool!=='shell')return;
      const record=trace.lookup(event);
      write('native-after',{...event,execution_id:record.execution_id});
      trace.finish(event);
      const exit=event.result.metadata?.exit;
      if(!Number.isInteger(exit))throw new Error('Missing actual host exit code');
      // OpenCode reports combined output. We do not invent a stdout/stderr split.
      const normalized={tool_name:'Bash',tool_input:{command:event.input.command},tool_result:{exit_code:exit,stdout:event.result.output?.output||'',stderr:''}};
      run(['learn','hook','--format','opencode','--learn-hook-type','post-tool-use'],normalized);
    });
  }
};
