// Evidence recorder for the sequential public Harbour fixture, not a global hook.
import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';

const role='Harbour Validator';
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const check=(condition,message)=>{if(!condition)throw new Error(message);};
const key=event=>JSON.stringify([event.sessionID,event.id]);
const save=(p,value)=>{
  fs.writeFileSync(p+'.tmp',JSON.stringify(value,null,2)+'\n');
  fs.renameSync(p+'.tmp',p);
};

/** Link the native before/after event with the actual rule and output bytes. */
export class ExecutionTrace {
  constructor(root) {
    this.root=root;
    this.pending=new Map();
    this.marker=path.join(root,'evidence/active-execution.json');
    fs.mkdirSync(path.join(root,'evidence/executions'),{recursive:true});
  }
  prepare(event,mode) {
    check(typeof event.id==='string'&&typeof event.sessionID==='string','Missing host call identity');
    check(!this.pending.has(key(event)),'Duplicate before event');
    const id=randomUUID();
    const directory=`evidence/executions/${id}`;
    fs.mkdirSync(path.join(this.root,directory));
    const config=read(path.resolve(this.root,mode.config));
    const local=config.roles[role].kg.automata_path?.Local;
    let ruleset=null;
    if(local) {
      const bytes=fs.readFileSync(path.resolve(this.root,local));
      const snapshot=`${directory}/compiled-rules.json`;
      fs.writeFileSync(path.join(this.root,snapshot),bytes);
      ruleset={path:snapshot,sha256:digest(bytes)};
      config.roles[role].kg.automata_path={Local:path.join(this.root,snapshot)};
    }
    const record={schema_version:1,adapter_version:'2.0.0',execution_id:id,
      host:{session_id:event.sessionID,message_id:event.messageID,tool_call_id:event.id,tool:event.tool},
      state:'prepared',started_at:new Date().toISOString(),rewrite_enabled:mode.rewrite,
      original_input:structuredClone(event.input),config_path:`${directory}/config.json`,ruleset,
      matched_rule:null,artifact_path:`${directory}/validation.json`,artifact:null};
    save(path.join(this.root,record.config_path),config);
    // The fixture's validator reads this marker; reject overlap instead of guessing attribution.
    fs.writeFileSync(this.marker,JSON.stringify({execution_id:id,artifact_path:record.artifact_path}),{flag:'wx'});
    this.pending.set(key(event),record);
    this.persist(record);
    return record;
  }
  lookup(event) {
    const r=this.pending.get(key(event));
    check(r,'No matching before event for this host session/tool call');
    return r;
  }
  persist(r) {save(path.join(this.root,`evidence/executions/${r.execution_id}/receipt.json`),r);}
  apply(event,command,hookReceipt) {
    const r=this.lookup(event);
    check(typeof command==='string','Missing hook command');
    if(command!==r.original_input.command) {
      const term=r.ruleset?read(path.join(this.root,r.ruleset.path)).data[r.original_input.command]:null;
      check(r.rewrite_enabled&&term&&term.nterm===command&&term.id!==undefined,'Rewrite has no exact compiled rule attribution');
      r.matched_rule={id:term.id,ruleset_sha256:r.ruleset.sha256,original:r.original_input.command,corrected:command};
    }
    r.hook_result=hookReceipt;
    event.input={...event.input,command};
    r.applied_input=structuredClone(event.input);
    r.state='applied';this.persist(r);
    return r;
  }
  release(event,r) {
    if(fs.existsSync(this.marker)&&read(this.marker).execution_id===r.execution_id)fs.unlinkSync(this.marker);
    this.pending.delete(key(event));
  }
  fail(event,error) {
    const r=this.pending.get(key(event));
    if(!r)return;
    r.state='evidence-error';r.error=String(error.message||error);r.finished_at=new Date().toISOString();
    this.persist(r);this.release(event,r);
  }
  finish(event) {
    const r=this.lookup(event);
    try {
      r.reported_after_input=structuredClone(event.input);
      r.host_status=event.status;
      if(event.error)r.host_error=structuredClone(event.error);
      check(event.status==='completed','Host did not report completed execution');
      r.executed_input=structuredClone(event.input);
      check(isDeepStrictEqual(r.applied_input,event.input),'Actual executed input differs from applied input');
      const exit=event.result.metadata?.exit;
      check(Number.isInteger(exit),'Missing actual host exit code');
      r.tool_result={exit_code:exit,combined_output:event.result.output?.output||'',host_status:event.status};
      const output=path.join(this.root,r.artifact_path);
      if(exit===0) {
        check(fs.existsSync(output),'Successful execution is missing output artifact');
        const bytes=fs.readFileSync(output);const content=JSON.parse(bytes);
        check(content.execution_id===r.execution_id,'Output execution ID does not match this call');
        check(isDeepStrictEqual(content,JSON.parse(r.tool_result.combined_output)),'Output artifact differs from actual tool result');
        r.artifact={path:r.artifact_path,sha256:digest(bytes),size_bytes:bytes.length,execution_id:content.execution_id};
      } else check(!fs.existsSync(output),'Failed command unexpectedly left a success artifact');
      r.state='completed';r.finished_at=new Date().toISOString();
      verifyReceipt(this.root,r);this.persist(r);this.release(event,r);
      return r;
    } catch(error) {this.fail(event,error);throw error;}
  }
}

/** Recheck persisted outputs; missing, stale, changed or foreign artifacts fail. */
export function verifyReceipt(root,r) {
  check(r.state==='completed','Execution is not completed');
  check(isDeepStrictEqual(r.applied_input,r.executed_input),'Actual executed input mismatch');
  check(r.hook_result.exit===0&&JSON.parse(r.hook_result.stdout).tool_input.command===r.applied_input.command,'Hook return differs from applied command');
  if(r.ruleset)check(digest(fs.readFileSync(path.join(root,r.ruleset.path)))===r.ruleset.sha256,'Compiled ruleset hash mismatch');
  if(r.original_input.command!==r.executed_input.command) {
    const term=r.ruleset&&read(path.join(root,r.ruleset.path)).data[r.original_input.command];
    check(r.rewrite_enabled&&term&&r.matched_rule?.id===term.id&&term.nterm===r.executed_input.command&&r.matched_rule.ruleset_sha256===r.ruleset.sha256&&r.matched_rule.original===r.original_input.command&&r.matched_rule.corrected===r.executed_input.command,'Matched rule identity mismatch');
  }
  check(Number.isInteger(r.tool_result.exit_code),'Missing tool exit code');
  if(r.tool_result.exit_code===0) {
    check(r.artifact&&r.artifact.path===r.artifact_path,'Missing artifact receipt');
    const bytes=fs.readFileSync(path.join(root,r.artifact.path));
    check(digest(bytes)===r.artifact.sha256,'Output artifact hash mismatch');
    const content=JSON.parse(bytes);
    check(content.execution_id===r.execution_id&&r.artifact.execution_id===r.execution_id,'Output execution ID mismatch');
    check(isDeepStrictEqual(content,JSON.parse(r.tool_result.combined_output)),'Tool output does not match artifact');
  } else check(r.artifact===null,'Failure cannot have a success artifact');
  return true;
}
