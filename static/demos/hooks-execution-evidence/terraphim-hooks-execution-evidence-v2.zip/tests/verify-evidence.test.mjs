import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const source=fileURLToPath(new URL('../recorded-run/',import.meta.url));
const verifier=fileURLToPath(new URL('../reproduction/verify.mjs',import.meta.url));
function fixture(t) {
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'hook-evidence-test-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  fs.cpSync(source,root,{recursive:true});
  const file=path.join(root,'evidence/host-events.jsonl');
  return {root,file,events:fs.readFileSync(file,'utf8').trim().split('\n').map(JSON.parse)};
}
function verify(f) {
  fs.writeFileSync(f.file,f.events.map(e=>JSON.stringify(e)).join('\n')+'\n');
  return spawnSync(process.execPath,[verifier,f.root],{encoding:'utf8'});
}
function orphan(f,type) {
  const event=structuredClone(f.events.find(e=>e.type===type));
  event.data.execution_id='orphan-execution';event.data.id='orphan-call';
  return event;
}
test('independent verifier accepts the actual recorded native run',t=>{
  const r=verify(fixture(t));assert.equal(r.status,0,r.stderr);
  assert.equal(JSON.parse(r.stdout).pass,true);
});
for(const types of [['native-before','native-after'],['native-before'],['native-after']]) {
  test(`independent verifier rejects orphan ${types.join(' and ')}`,t=>{
    const f=fixture(t);f.events.push(...types.map(type=>orphan(f,type)));
    const r=verify(f);assert.notEqual(r.status,0);assert.match(r.stderr,/Unmatched native event/);
  });
}
test('independent verifier rejects a native event without an execution ID',t=>{
  const f=fixture(t);const e=orphan(f,'native-before');delete e.data.execution_id;f.events.push(e);
  const r=verify(f);assert.notEqual(r.status,0);assert.match(r.stderr,/Unmatched native event/);
});
test('independent verifier rejects a duplicate native call',t=>{
  const f=fixture(t);f.events.push(structuredClone(f.events.find(e=>e.type==='native-before')));
  const r=verify(f);assert.notEqual(r.status,0);assert.match(r.stderr,/native-before count/);
});
test('independent verifier rejects a missing native completion',t=>{
  const f=fixture(t);f.events.splice(f.events.findIndex(e=>e.type==='native-after'),1);
  const r=verify(f);assert.notEqual(r.status,0);assert.match(r.stderr,/native-after count/);
});
test('independent verifier rejects duplicate receipt execution IDs',t=>{
  const f=fixture(t);const dir=path.join(f.root,'evidence/executions');const ids=fs.readdirSync(dir);
  const a=JSON.parse(fs.readFileSync(path.join(dir,ids[0],'receipt.json')));
  const file=path.join(dir,ids[1],'receipt.json');const b=JSON.parse(fs.readFileSync(file));
  b.execution_id=a.execution_id;fs.writeFileSync(file,JSON.stringify(b));
  const r=verify(f);assert.notEqual(r.status,0);assert.match(r.stderr,/Unique receipt execution IDs/);
});
