import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { ExecutionTrace, verifyReceipt } from '../reproduction/fixture/.opencode/plugins/terraphim-demo/execution-trace.mjs';

const original='python3 validate-brief.py --chek';
const corrected='python3 validate-brief.py --check';
function fixture(t) {
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'hook-trace-test-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  fs.writeFileSync(path.join(root,'compiled.json'),JSON.stringify({name:'compiled_corrections',data:{[original]:{id:1,nterm:corrected}}}));
  fs.writeFileSync(path.join(root,'config.json'),JSON.stringify({roles:{'Harbour Validator':{kg:{automata_path:{Local:path.join(root,'compiled.json')}}}}}));
  const recorder=new ExecutionTrace(root);
  const event={sessionID:'session-one',messageID:'message-one',id:'call-one',tool:'shell',input:{command:original}};
  return {root,recorder,event};
}
function complete(f,{exit=0,command=corrected,artifactID,writeOutput=true}={}) {
  const r=f.recorder.prepare(f.event,{config:'config.json',rewrite:true});
  f.recorder.apply(f.event,command,{exit:0,stdout:JSON.stringify({tool_name:'Bash',tool_input:{command}})});
  const result={project:'Harbour',status:'valid',fields:['Decision','Risk','Owner'],execution_id:artifactID||r.execution_id};
  if(writeOutput) fs.writeFileSync(path.join(f.root,r.artifact_path),JSON.stringify(result));
  f.event.status='completed';
  f.event.result={metadata:{exit},output:{output:JSON.stringify(result)}};
  return {r,result};
}
test('same execution links rule snapshot, actual input, result and output SHA',t=>{
  const f=fixture(t);complete(f);
  const receipt=f.recorder.finish(f.event);
  assert.equal(receipt.matched_rule.id,1);
  assert.equal(receipt.original_input.command,original);
  assert.equal(receipt.executed_input.command,corrected);
  assert.equal(receipt.matched_rule.ruleset_sha256,receipt.ruleset.sha256);
  assert.equal(verifyReceipt(f.root,receipt),true);
  assert.equal(fs.existsSync(path.join(f.root,'evidence/active-execution.json')),false);
});
test('compiled graph snapshot survives source replacement',t=>{
  const f=fixture(t);const r=f.recorder.prepare(f.event,{config:'config.json',rewrite:true});
  fs.writeFileSync(path.join(f.root,'compiled.json'),'{}');
  const config=JSON.parse(fs.readFileSync(path.join(f.root,r.config_path)));
  assert.equal(config.roles['Harbour Validator'].kg.automata_path.Local,path.join(f.root,r.ruleset.path));
  assert.equal(JSON.parse(fs.readFileSync(path.join(f.root,r.ruleset.path))).data[original].id,1);
  f.recorder.fail(f.event,new Error('test completed'));
});
test('foreign execution ID in output is rejected',t=>{
  const f=fixture(t);complete(f,{artifactID:'old-run'});
  assert.throws(()=>f.recorder.finish(f.event),/execution ID/);
});
test('missing output cannot qualify a successful command',t=>{
  const f=fixture(t);complete(f,{writeOutput:false});
  assert.throws(()=>f.recorder.finish(f.event),/missing output/);
});
test('actual executed command must equal the applied command',t=>{
  const f=fixture(t);complete(f);f.event.input.command=original;
  assert.throws(()=>f.recorder.finish(f.event),/executed input/);
});
test('changed command without an exact compiled rule is rejected',t=>{
  const f=fixture(t);f.recorder.prepare(f.event,{config:'config.json',rewrite:true});
  assert.throws(()=>f.recorder.apply(f.event,'different command',{}),/exact compiled rule/);
  f.recorder.fail(f.event,new Error('rejected'));
});
test('unmatched after event is rejected',t=>{
  const f=fixture(t);assert.throws(()=>f.recorder.finish(f.event),/matching before/);
});
test('fixture rejects concurrency instead of attributing another call output',t=>{
  const f=fixture(t);const r=f.recorder.prepare(f.event,{config:'config.json',rewrite:true});
  const other={...f.event,id:'call-two'};
  assert.throws(()=>f.recorder.prepare(other,{config:'config.json',rewrite:true}),/EEXIST/);
  assert.equal(JSON.parse(fs.readFileSync(path.join(f.root,'evidence/active-execution.json'))).execution_id,r.execution_id);
  f.recorder.fail(f.event,new Error('interrupted'));
});
test('failed tool outcome is retained without a success artifact',t=>{
  const f=fixture(t);complete(f,{exit:2,command:original,writeOutput:false});
  const r=f.recorder.finish(f.event);assert.equal(r.tool_result.exit_code,2);assert.equal(r.artifact,null);
  assert.equal(r.matched_rule,null);assert.equal(verifyReceipt(f.root,r),true);
});
test('altered output bytes are detected on readback',t=>{
  const f=fixture(t);complete(f);const r=f.recorder.finish(f.event);
  fs.appendFileSync(path.join(f.root,r.artifact.path),' ');
  assert.throws(()=>verifyReceipt(f.root,r),/artifact hash/);
});
test('a different host session cannot close an active call',t=>{
  const f=fixture(t);complete(f);
  assert.throws(()=>f.recorder.finish({...f.event,sessionID:'different-session'}),/matching before/);
  f.recorder.fail(f.event,new Error('interrupted'));
});
test('blocked host call is retained without claiming execution',t=>{
  const f=fixture(t);const r=f.recorder.prepare(f.event,{config:'config.json',rewrite:true});
  f.recorder.apply(f.event,corrected,{});
  f.event.status='error';f.event.error={message:'Permission denied'};
  assert.throws(()=>f.recorder.finish(f.event),/did not report completed/);
  const saved=JSON.parse(fs.readFileSync(path.join(f.root,`evidence/executions/${r.execution_id}/receipt.json`)));
  assert.equal(saved.state,'evidence-error');assert.equal(saved.executed_input,undefined);
  assert.deepEqual(saved.host_error,f.event.error);
});

test('modified compiled rule version fails readback',t=>{
  const f=fixture(t);complete(f);const r=f.recorder.finish(f.event);
  fs.appendFileSync(path.join(f.root,r.ruleset.path),' ');
  assert.throws(()=>verifyReceipt(f.root,r),/ruleset hash/);
});
test('hook return must agree with the applied and executed command',t=>{
  const f=fixture(t);complete(f);const r=f.recorder.finish(f.event);
  r.hook_result.stdout=JSON.stringify({tool_input:{command:original}});
  assert.throws(()=>verifyReceipt(f.root,r),/Hook return/);
});
