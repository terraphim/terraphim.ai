# Hook released-binary qualification — 13 October 2026

Status: actual hook-to-host execution passes for the public Harbour fixture; privacy claims fail and must be narrowed. No publication performed.

## What actually ran

- Public `terraphim-agent` 1.21.19 Apple Silicon archive and published SHA256SUMS verified; shared receipt copied from the memory qualifier.
- OpenCode 2.0.20, existing Kimi coding-plan `kimi-code-plan-global/k3`, isolated process `OPENCODE_CONFIG_DIR`, project-local V2 adapter. No metered fallback or global-hook installation.
- Actual baseline host attempt `python3 validate-brief.py --chek` produced argparse failure, exit 2, no validation.json. Raw before/after host events retained.
- Actual after-tool event normalized by the included adapter and passed directly to `learn hook --format opencode --learn-hook-type post-tool-use`; learning Markdown persisted with command/error/exit/provenance.
- `learn correct` saved the proposed correction. `learn compile` still produced zero entries from that failure record alone, proving manual promotion is necessary in this release.
- `learn correction add --correction-type tool-preference` explicitly promoted the reviewed mapping. `learn compile` produced one typed thesaurus entry. `learn export-kg` produced reviewable Markdown containing `synonyms:: python3 validate-brief.py --chek`.
- Role loaded compiled JSON. Rewrite disabled preserved --chek and warned; enabled returned --check; unrelated command and unrelated role stayed unchanged. Guard denied a destructive-looking input string; that string was never executed.
- A new actual OpenCode process attempted --chek. Adapter applied the released hook's returned --check through V2 `event.input`. Host after-tool event reports command --check, exit 0, real valid-Harbour JSON; fixture/validation.json exists with the expected fields.

## Boundaries established by negative observations

- Release source `learnings/hook.rs` ignores the format argument and parses only normalized `tool_name/tool_input/tool_result`. Supplying the native OpenCode event returned exit 0 but created no learning. Never equate fail-open exit 0 with capture success.
- Released PreToolUse rewrites `tool_input.command`; it does not emit Claude/Codex `hookSpecificOutput.updatedInput`. The explicit tested OpenCode adapter is part of this demonstration.
- Loading this exported Markdown as the local KG did not produce substitution in the tested configuration. Loading `learn compile` JSON did. Record the demonstrated compiled-JSON bridge; do not claim automatic export activation.
- `source: Global` in the saved learning refers to the release's env-directed fallback storage selection. The actual directory is isolated beneath this fixture, not the user's personal global store.
- `learn correct` did not refresh the stored importance_has_correction flag. The correction field itself and subsequent list readback are present.

## Fake-canary privacy results

All canaries were deliberately fake. See privacy/report.json and receipts/privacy-*.json / *-stored.md.

| Case | Raw fake secret in saved learning | Raw fake secret in hook stdout |
|---|---|---|
| AWS-shaped command token | yes | no |
| AWS-shaped error token | no | no |
| AWS-shaped current-directory segment | yes | no |
| AWS-shaped extra metadata token | no (metadata not stored) | no |
| GitHub-shaped command token | yes | yes |

Source `capture.rs:1010` redacts error output, but copies actual command and current working directory unredacted. `contains_secrets` has a narrower pattern set than `redact_secrets`, so some pass-through strings skip redaction. These are outstanding product defects, not a successful privacy qualification. The demonstration uses public fixture data only.

## Reproduction and evidence

- `host/native-events.jsonl`, `host/baseline-host.jsonl`: original observed baseline.
- `host/adapter-events.jsonl`, `host/live-learning-host.jsonl`, `host/corrected-host.jsonl`: directly integrated actual host runs and release invocations.
- `receipts/`: exact CLI argv, stdin, stdout, stderr, exit code and elapsed time, plus saved before/after learning files.
- `live-compiled-corrections.json`, `live-kg/`, `fixture/validation.json`: actual outputs.
- `reproduction/`: portable clean-fixture script and local host adapter.
- Fresh-extraction verification is recorded separately and must pass before calling the download reproducible.

Pinned source: https://github.com/terraphim/terraphim-clients/tree/v1.21.19
Host contract: https://dev.opencode.ai/v2/docs/build/plugins/ (tool execute.before/after)

No credentials, private transcripts, private project contents, source-code changes, posts or global hook configuration are part of this evidence package.
