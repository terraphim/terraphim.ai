---
id: fa68f6b8ae1240d186f21b75126caf5e-1791873046085
command: python3 validate-brief.py --chek
exit_code: 2
source: Global
captured_at: 2026-10-13T06:30:46.085959+00:00
working_dir: /private/tmp/terraphim-agent-hooks-fresh-run2-20261013
tags:
  - learning
  - exit-2
importance_total: 0.3200
importance_severity: 0.4000
importance_repetition: 0
importance_recency: 1.0000
importance_has_correction: false
---

## Command

`python3 validate-brief.py --chek`

## Error Output

```
usage: validate-brief.py [-h] --check
validate-brief.py: error: the following arguments are required: --check

```

