---
type::: kg_entry
correction_type: tool_preference
captured_at: 2026-10-13T06:30:51.942180+00:00
source: learned
synonyms:: python3 validate-brief.py --chek
priority:: 70
pinned:: false
---

# python3 validate-brief.py --check

## Original

Multiple alternatives resolved to this correction:
- `python3 validate-brief.py --chek`

## Corrected

`python3 validate-brief.py --check`

## Context

- Manually reviewed correction from actual captured learning fa68f6b8ae1240d186f21b75126caf5e-1791873046085

