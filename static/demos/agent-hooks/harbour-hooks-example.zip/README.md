# A failed command, a saved correction, and real execution

This public Harbour project fixture shows the released `terraphim-agent` **v1.21.19** learning path. OpenCode **2.0.20** tries `python3 validate-brief.py --chek`, receives exit 2, and its actual after-tool event is captured through the included project-local adapter. A human-reviewed correction is explicitly promoted to a tool preference and compiled. In a fresh coding-host process, the same attempted command is rewritten to `--check`, actually runs with exit 0, and writes `validation.json`.

The adapter translates OpenCode's real event into Terraphim's normalized hook schema and applies Terraphim's returned command through OpenCode's mutable before-tool input. This adapter is included in the example; it is not a claim that `--format opencode` alone handles the native event or that returning JSON executes it.

## Reproduce

1. Download your agent archive and `SHA256SUMS` from [clients v1.21.19](https://github.com/terraphim/terraphim-clients/releases/tag/v1.21.19). Check the archive hash against the published list before extracting. The recorded run used the Apple Silicon archive, SHA-256 `47e32a476865041e701c6e49201a51df7741f20ccb18060872a970ce4aa33f3f`.
2. Have Python 3 and OpenCode 2.0.20 installed. Use an already authenticated subscription-backed coding model. The recording used `kimi-code-plan-global/k3`; the script does not install credentials, buy API credits, or choose a fallback provider.
3. From this extracted directory, run:

```sh
python3 reproduce.py \
  --agent /absolute/path/to/terraphim-agent \
  --model kimi-code-plan-global/k3 \
  --output /absolute/path/to/a-new-harbour-run
```

The output directory must be new. All learning data, settings, hooks, graph files and receipts are created there. `OPENCODE_CONFIG_DIR` points at its empty local configuration directory for these processes. Your global hooks and Terraphim stores are not changed; the host uses its existing login. Only the fictional public brief and command are sent to the coding model.

Read `evidence/verification.json`, `evidence/host-events.jsonl`, `evidence/baseline-host.jsonl`, `evidence/corrected-host.jsonl` and `validation.json`. The script asserts the actual before/after command and exit code, the saved learning, rewrite-disabled behavior, unrelated command/role controls, and result file. It raises an error if the model does not perform the expected single command; it never manufactures a successful host trace.

## The deliberate promotion step

`learn correct ID --correction 'python3 validate-brief.py --check'` adds a suggested correction to a failure record. In this release, `learn compile` compiles **tool-preference correction records**, not that suggested-correction field. The example explicitly calls:

```sh
terraphim-agent learn correction add \
  --correction-type tool-preference \
  --original 'python3 validate-brief.py --chek' \
  --corrected 'python3 validate-brief.py --check' \
  --context 'Manually reviewed correction from the captured failure'
terraphim-agent learn compile --output compiled-corrections.json
terraphim-agent learn export-kg --output kg
```

The selected role reads `compiled-corrections.json`. `kg/` contains the exported `synonyms::` Markdown for review. Exporting Markdown alone is not represented as activating the tested hook.

## Scope

This is a harmless public fixture, not a recommendation to capture secrets. Fake-canary tests found v1.21.19 redaction gaps in saved command/cwd fields and some hook passthrough values; no blanket secret-redaction or no-network guarantee is made. The coding host uses its configured online model. Terraphim's correction and rewrite in this example use the local saved graph. OpenCode provides combined shell output, so the adapter does not invent a separate stdout/stderr split.

No destructive command is executed. The guard check in the internal qualification only supplied a string to the hook. The downloaded example grants its host shell permission for the two local validator commands and denies other tool actions.
